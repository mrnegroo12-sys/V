package com.sketchbot.app

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** قائمة تمرير ارتفاعها يتبع المحتوى لكن لا يتجاوز حدّاً أقصى */
private class CappedScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        super.onMeasure(widthSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

/**
 * بطاقة «مكتبة الفرشات» في صفحة الرسم:
 * تشغيل/إيقاف الوضع الذكي، عدد الأحجام، قائمة الفرشات (تمرير)، المعايرة التلقائية والإدخال اليدوي،
 * وتقرير الأحجام المستخدمة، وتبديل المعاينة بين المحاكاة والأصل.
 */
class BrushPanel(
    private val ctx: Context,
    private val onPlanChange: () -> Unit,
    private val onViewToggle: (Boolean) -> Unit
) : LinearLayout(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = (v * d).toInt()
    private val prefs = ctx.getSharedPreferences("sb", Context.MODE_PRIVATE)

    var smartOn: Boolean = prefs.getBoolean("smartOn", true)
        private set
    var tierCount: Int = prefs.getInt("tierCount", 0)
        private set
    var showSim: Boolean = prefs.getBoolean("showSim", true)
        private set

    private val list = LinearLayout(ctx).apply { orientation = VERTICAL }
    private val report = Th.text(ctx, "", 12f, Th.MUTED)
    private val tierLabel = Th.text(ctx, "", 13f, Th.BROWN, true)
    private lateinit var viewBtn: TextView

    private fun toast(msg: String) = Toast.makeText(ctx, Tr.t(msg), Toast.LENGTH_LONG).show()

    private fun pill(text: String, onClick: () -> Unit): TextView = Th.text(ctx, Tr.t(text), 13f, Th.BROWN, true).apply {
        gravity = Gravity.CENTER
        background = WarmDrawable(WarmDrawable.BTN, 14f, d)
        setPadding(dp(12f), dp(9f), dp(12f), dp(9f))
        Th.pressable(this)
        setOnClickListener { onClick() }
    }

    init {
        orientation = VERTICAL
        background = WarmDrawable(WarmDrawable.GLASS, 26f, d)
        setPadding(dp(14f), dp(14f), dp(14f), dp(14f))
        elevation = 6f * d
        BrushLib.seed(ctx)

        // ---- العنوان ----
        addView(LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(IconView(ctx, Ic.BRUSH, Color.parseColor("#BE848C"), Color.parseColor("#7A4A52"), 0, true), LayoutParams(dp(52f), dp(52f)))
            addView(Th.text(ctx, Tr.t("مكتبة الفرشات"), 18f, Th.BROWN, true), LayoutParams(0, -2, 1f).apply { leftMargin = dp(14f) })
        })

        // ---- الوضع الذكي ----
        val swSmart = WarmSwitch(ctx).apply { checked = smartOn }
        swSmart.onChange = { v ->
            smartOn = v
            prefs.edit().putBoolean("smartOn", v).apply()
            onPlanChange()
        }
        addView(LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(Th.text(ctx, Tr.t("التحليل الذكي بالفرشات"), 14.5f, Th.BROWN, true), LayoutParams(0, -2, 1f))
            addView(swSmart)
        }, LayoutParams(-1, -2).apply { topMargin = dp(12f) })
        addView(
            Th.text(ctx, Tr.t("يقرأ البوت الصورة ويختار الفرشات والأحجام (حتى 100 حجم) والمعاينة تُظهر المحاكاة بهذه الفرشات. يعمل في وضع الفرشاة الدقيقة."), 11.5f, Th.MUTED),
            LayoutParams(-1, -2).apply { topMargin = dp(4f) }
        )

        // ---- عدد الأحجام ----
        tierLabel.text = tierText()
        val seek = SeekBar(ctx).apply {
            max = 100
            progress = tierCount
            progressTintList = ColorStateList.valueOf(Color.parseColor("#F26B1D"))
            thumbTintList = ColorStateList.valueOf(Color.parseColor("#F26B1D"))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    tierCount = p
                    tierLabel.text = tierText()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    prefs.edit().putInt("tierCount", tierCount).apply()
                    onPlanChange()
                }
            })
        }
        addView(tierLabel, LayoutParams(-2, -2).apply { topMargin = dp(10f) })
        addView(seek, LayoutParams(-1, dp(36f)))

        // ---- الأزرار ----
        addView(LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            addView(pill("＋ معايرة تلقائية") { askCalibrate() }, LayoutParams(0, -2, 1f).apply { rightMargin = dp(4f) })
            addView(pill("＋ إدخال يدوي") { askManual() }, LayoutParams(0, -2, 1f).apply { leftMargin = dp(4f) })
        }, LayoutParams(-1, -2).apply { topMargin = dp(8f) })
        viewBtn = pill(viewText()) {
            showSim = !showSim
            prefs.edit().putBoolean("showSim", showSim).apply()
            viewBtn.text = Tr.t(viewText())
            onViewToggle(showSim)
        }
        addView(viewBtn, LayoutParams(-1, -2).apply { topMargin = dp(8f) })

        // ---- قائمة الفرشات (تمرير) ----
        val scroll = CappedScroll(ctx, dp(300f)).apply {
            isVerticalScrollBarEnabled = true
            addView(list)
            // القائمة داخل صفحة تتمرر: نمنع الصفحة من خطف اللمسة أثناء تمرير القائمة
            setOnTouchListener { v, _ -> v.parent.requestDisallowInterceptTouchEvent(true); false }
        }
        addView(scroll, LayoutParams(-1, -2).apply { topMargin = dp(12f) })

        // ---- تقرير الأحجام ----
        addView(report, LayoutParams(-1, -2).apply { topMargin = dp(10f) })
        refresh()
    }

    private fun tierText(): String =
        Tr.t("عدد الأحجام") + ": " + (if (tierCount == 0) Tr.t("تلقائي") else "$tierCount")

    private fun viewText(): String =
        if (showSim) "المعاينة: محاكاة الفرشات (اضغط للأصل)" else "المعاينة: الأصل (اضغط للمحاكاة)"

    fun setReport(text: String) {
        report.text = text
    }

    fun refresh() {
        list.removeAllViews()
        val brushes = BrushLib.load(ctx)
        val taught = BrushLib.taught(ctx)
        val primary = brushes.firstOrNull { it.on }
        if (brushes.isEmpty()) {
            list.addView(Th.text(ctx, Tr.t("لا توجد فرشات بعد. اضغط «معايرة تلقائية» أو «إدخال يدوي»."), 13f, Th.MUTED))
        }
        for (b in brushes) {
            list.addView(row(b, primary != null && b.id == primary.id, b.id in taught, brushes), LayoutParams(-1, -2).apply { topMargin = dp(8f) })
        }
    }

    private fun row(b: Brush, isPrimary: Boolean, isTaught: Boolean, all: MutableList<Brush>): LinearLayout {
        val roleName = when (b.role) { 1 -> "تعبئة"; 2 -> "خطوط"; else -> "عام" }
        val state = when {
            !b.on -> "متوقفة"
            isPrimary -> "⭐ الأساسية: اخترها يدوياً قبل البدء"
            isTaught -> "✔ يبدّلها البوت تلقائياً"
            else -> "علّمها لكي يستخدمها البوت"
        }
        val sw = WarmSwitch(ctx).apply { checked = b.on }
        sw.onChange = { v ->
            b.on = v
            BrushLib.save(ctx, all)
            refresh()
            onPlanChange()
        }
        val title = Th.text(ctx, b.name, 14f, Th.BROWN, true)
        val info = Th.text(
            ctx,
            "${b.minPx().toInt()}–${b.maxPx().toInt()} px | " + Tr.t("الدور") + ": " + Tr.t(roleName) + " | " + Tr.t(state),
            11.5f, Th.MUTED
        )
        // الضغط على السطر الثاني يبدّل الدور: عام ← تعبئة ← خطوط
        info.setOnClickListener {
            b.role = (b.role + 1) % 3
            BrushLib.save(ctx, all)
            refresh()
            onPlanChange()
        }
        // ضغطة مطوّلة على الاسم تجعلها الفرشاة الأساسية (الأولى في القائمة)
        title.setOnLongClickListener {
            all.remove(b)
            all.add(0, b)
            BrushLib.save(ctx, all)
            refresh()
            onPlanChange()
            true
        }
        val col = LinearLayout(ctx).apply {
            orientation = VERTICAL
            addView(title)
            addView(info)
        }
        return LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = WarmDrawable(WarmDrawable.GLASS, 16f, d)
            setPadding(dp(10f), dp(8f), dp(10f), dp(8f))
            addView(sw, LayoutParams(dp(52f), dp(30f)))
            addView(col, LayoutParams(0, -2, 1f).apply { leftMargin = dp(10f); rightMargin = dp(6f) })
            addView(pill("علّم") {
                val svc = DrawService.instance
                if (svc == null) toast("فعّل خدمة إمكانية الوصول أولاً") else svc.teachBrushSel(b.id, b.name)
            }, LayoutParams(-2, -2).apply { rightMargin = dp(4f) })
            addView(pill("🗑") {
                BrushLib.remove(ctx, b.id)
                refresh()
                onPlanChange()
            }, LayoutParams(-2, -2))
        }
    }

    private fun askCalibrate() {
        val edit = EditText(ctx).apply {
            hint = Tr.t("اسم الفرشاة (مثل: قلم رصاص)")
            setSingleLine()
        }
        val box = LinearLayout(ctx).apply {
            orientation = VERTICAL
            setPadding(dp(20f), dp(8f), dp(20f), 0)
            addView(edit)
        }
        AlertDialog.Builder(ctx)
            .setTitle(Tr.t("معايرة فرشاة جديدة"))
            .setMessage(Tr.t("اختر الفرشاة في Sketchbook أولاً، وتأكد أن وسط منطقة الرسم فارغ ثم اضغط ابدأ. يلزم أن تكون علّمت حقل Size."))
            .setView(box)
            .setPositiveButton(Tr.t("ابدأ")) { _, _ ->
                val name = edit.text.toString().trim().ifEmpty { Tr.t("فرشاة") }
                val svc = DrawService.instance
                if (svc == null) toast("فعّل خدمة إمكانية الوصول أولاً") else svc.calibrateToLibrary(name, 0)
            }
            .setNegativeButton(Tr.t("إلغاء"), null)
            .show()
    }

    private fun askManual() {
        fun field(hintText: String, numeric: Boolean) = EditText(ctx).apply {
            hint = Tr.t(hintText)
            setSingleLine()
            if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val name = field("اسم الفرشاة", false)
        val a = field("عرض الخط بالبكسل عند Size 10", true)
        val b = field("عرض الخط بالبكسل عند Size 50", true)
        val box = LinearLayout(ctx).apply {
            orientation = VERTICAL
            setPadding(dp(20f), dp(8f), dp(20f), 0)
            addView(name)
            addView(a)
            addView(b)
        }
        AlertDialog.Builder(ctx)
            .setTitle(Tr.t("إدخال فرشاة يدوياً"))
            .setView(box)
            .setPositiveButton(Tr.t("حفظ")) { _, _ ->
                val pa = a.text.toString().toFloatOrNull()
                val pb = b.text.toString().toFloatOrNull()
                if (pa == null || pb == null || pa <= 0f || pb <= pa) {
                    toast("أدخل عرضين صحيحين (الثاني أكبر من الأول)")
                } else {
                    val nm = name.text.toString().trim().ifEmpty { Tr.t("فرشاة") }
                    val samples = ArrayList<FloatArray>()
                    samples.add(floatArrayOf(10f, pa))
                    samples.add(floatArrayOf(50f, pb))
                    BrushLib.add(ctx, nm, samples, 0)
                    refresh()
                    onPlanChange()
                }
            }
            .setNegativeButton(Tr.t("إلغاء"), null)
            .show()
    }
}
