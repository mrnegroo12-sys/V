package com.sketchbot.app

import android.content.Context

/** ترجمة بسيطة: العربية هي الأصل، وتُستبدل العبارات المعروفة بالإنجليزية أو الفرنسية */
object Tr {
    @Volatile var lang: String = "ar"

    fun init(ctx: Context) {
        lang = ctx.getSharedPreferences("sb", Context.MODE_PRIVATE).getString("lang", "ar") ?: "ar"
    }

    fun next(ctx: Context) {
        lang = when (lang) { "ar" -> "en"; "en" -> "fr"; else -> "ar" }
        ctx.getSharedPreferences("sb", Context.MODE_PRIVATE).edit().putString("lang", lang).apply()
    }

    private val D: List<Array<String>> = listOf(
        arrayOf("افتح لوحة الطبقات في Sketchbook بنفسك، ثم اضغط متابعة", "Open the Layers panel in Sketchbook yourself, then tap Continue", "Ouvrez vous-même le panneau Calques dans Sketchbook, puis touchez Continuer"),
        arrayOf("اضغط أيقونة الطبقات", "Tap the Layers icon", "Touchez l'icône Calques"),
        arrayOf("اضغط زر ⊕ إضافة طبقة جديدة", "Tap the ⊕ Add new layer button", "Touchez le bouton ⊕ Nouveau calque"),
        arrayOf("تم حفظ الطبقات. أغلق لوحة الطبقات الآن", "Layers saved. Close the Layers panel now", "Calques enregistrés. Fermez le panneau Calques"),
        arrayOf("أداة التعبئة (Fill / سطل الطلاء)", "Fill tool (paint bucket)", "Outil Remplissage (seau)"),
        arrayOf("أداة التنعيم (Smudge)", "Smudge tool", "Outil Doigt (Smudge)"),
        arrayOf("الفرشاة أو القلم الرفيع", "Brush or fine pen", "Pinceau ou stylo fin"),
        arrayOf("اضغط أيقونة الفرش في الشريط العلوي (التي تفتح لوحة الأدوات)", "Tap the Brush icon in the top bar (opens the tools panel)", "Touchez l'icône Pinceau dans la barre du haut (ouvre les outils)"),
        arrayOf("افتح لوحة الفرش بنفسك الآن ثم اضغط متابعة", "Open the brush panel yourself, then tap Continue", "Ouvrez le panneau des pinceaux, puis touchez Continuer"),
        arrayOf("اضغط على", "Tap", "Touchez"),
        arrayOf("داخل اللوحة", "inside the panel", "dans le panneau"),
        arrayOf("اختر", "Select", "Choisissez"),
        arrayOf("بنفسك الآن (اضغط عليها فعلاً) ثم اضغط متابعة", "yourself now (really tap it), then tap Continue", "vous-même (touchez-le vraiment), puis Continuer"),
        arrayOf("اضغط الزر الذي يُغلق اللوحة (مثلاً أيقونة الفرش مجدداً)، وإن كانت تُغلق تلقائياً فاضغط تخطي", "Tap the button that closes the panel (e.g. the brush icon again). If it closes by itself, tap Skip", "Touchez le bouton qui ferme le panneau. S'il se ferme seul, touchez Ignorer"),
        arrayOf("تم حفظ", "Saved:", "Enregistré :"),
        arrayOf("تأكد أن اللوحة مغلقة الآن", "make sure the panel is closed now", "vérifiez que le panneau est fermé"),
        arrayOf("المحرر مغلق الآن. اضغط أيقونة اللون في الشريط العلوي (عجلة الألوان)", "The editor is closed. Tap the Color icon in the top bar (color wheel)", "L'éditeur est fermé. Touchez l'icône Couleur (roue) dans la barre du haut"),
        arrayOf("افتح محرر اللون بنفسك، ثم اضغط متابعة", "Open the color editor yourself, then tap Continue", "Ouvrez l'éditeur de couleur, puis touchez Continuer"),
        arrayOf("اضغط على حقل HEX (المكان الذي يُكتب فيه رمز اللون)", "Tap the HEX field (where the color code is typed)", "Touchez le champ HEX (où l'on saisit le code couleur)"),
        arrayOf("اضغط ✕ الذي يغلق محرر اللون", "Tap ✕ that closes the color editor", "Touchez ✕ qui ferme l'éditeur de couleur"),
        arrayOf("تم حفظ اللون. أغلق محرر اللون الآن", "Color saved. Close the color editor now", "Couleur enregistrée. Fermez l'éditeur"),
        arrayOf("تعذّر الكتابة تلقائياً: اكتب", "Could not type automatically: type", "Saisie automatique impossible : saisissez"),
        arrayOf("اكتب", "Type", "Saisissez"),
        arrayOf("في حقل HEX بنفسك (الرمز في الحافظة) ثم اضغط متابعة", "in the HEX field yourself (code is in the clipboard), then tap Continue", "dans le champ HEX (code dans le presse-papiers), puis Continuer"),
        arrayOf("المرحلة", "Phase", "Étape"),
        arrayOf("اختر اللون ثم متابعة", "Pick the color, then Continue", "Choisissez la couleur puis Continuer"),
        arrayOf("اللون", "Color", "Couleur"),
        arrayOf("لون", "Color", "Couleur"),
        arrayOf("من", "of", "sur"),
        arrayOf("الخطوط الخارجية", "Outlines", "Contours"),
        arrayOf("الخطوط", "Lines", "Lignes"),
        arrayOf("تنعيم الحدود بين الألوان", "Blend color borders", "Fondu des bordures"),
        arrayOf("الآن اضغط الزاوية السفلية اليمنى لمنطقة الرسم", "Now tap the bottom-right corner of the drawing area", "Touchez le coin inférieur droit de la zone de dessin"),
        arrayOf("اضغط الزاوية العليا اليسرى لمنطقة الرسم", "Tap the top-left corner of the drawing area", "Touchez le coin supérieur gauche de la zone de dessin"),
        arrayOf("المساحة صغيرة جداً، أعد المحاولة", "Area too small, try again", "Zone trop petite, réessayez"),
        arrayOf("تم حفظ منطقة الرسم", "Drawing area saved", "Zone de dessin enregistrée"),
        arrayOf("اكتمل الرسم", "Drawing complete", "Dessin terminé"),
        arrayOf("تم الإيقاف", "Stopped", "Arrêté"),
        arrayOf("تم مسح تعليم اللون: سيعود الاختيار اليدوي", "Color teaching cleared: manual selection again", "Couleur effacée : sélection manuelle"),
        arrayOf("تم مسح تعليم أداة Fill: سيطلب منك اختيارها يدوياً", "Fill teaching cleared: you'll pick it manually", "Fill effacé : sélection manuelle"),
        arrayOf("تم مسح تعليم الفرشاة: سيطلب منك اختيارها يدوياً", "Brush teaching cleared: you'll pick it manually", "Pinceau effacé : sélection manuelle"),
        arrayOf("حدّد منطقة الرسم (⛶) أولاً", "Set the drawing area (⛶) first", "Définissez d'abord la zone de dessin (⛶)"),
        arrayOf("اختر صورة من التطبيق أولاً", "Pick an image in the app first", "Choisissez d'abord une image dans l'app"),
        arrayOf("جاري التحضير...", "Preparing...", "Préparation..."),
        arrayOf("التنعيم يحتاج طبقة واحدة، تم تخطيه", "Smoothing needs a single layer, skipped", "Le fondu nécessite un seul calque, ignoré"),
        arrayOf("اختر أداة التنعيم (Smudge) بنفسك ثم اضغط متابعة", "Select the Smudge tool yourself, then tap Continue", "Choisissez l'outil Smudge, puis Continuer"),
        arrayOf("اختر أداة التعبئة (Fill) في Sketchbook بنفسك ثم اضغط متابعة", "Select the Fill tool in Sketchbook yourself, then tap Continue", "Choisissez l'outil Fill dans Sketchbook, puis Continuer"),
        arrayOf("اختر الفرشاة/القلم الرفيع في Sketchbook بنفسك ثم اضغط متابعة", "Select the brush / fine pen in Sketchbook yourself, then tap Continue", "Choisissez le pinceau / stylo fin dans Sketchbook, puis Continuer"),
        arrayOf("القياس التلقائي يتطلب Android 11 فما فوق", "Auto-measure requires Android 11+", "La mesure auto nécessite Android 11+"),
        arrayOf("سيرسم خطاً تجريبياً في وسط منطقة الرسم", "A test line will be drawn in the middle of the area", "Un trait d'essai sera tracé au centre de la zone"),
        arrayOf("علّم اللون أولاً (🎨)", "Teach the color first (🎨)", "Indiquez d'abord la couleur (🎨)"),
        arrayOf("ابدأ", "Start", "Démarrer"),
        arrayOf("إيقاف", "Stop", "Arrêter"),
        arrayOf("المنطقة", "Area", "Zone"),
        arrayOf("طبقات", "Layers", "Calques"),
        arrayOf("الفرشاة", "Brush", "Pinceau"),
        arrayOf("اختبار", "Test", "Test"),
        arrayOf("قياس الفرشاة", "Measure brush", "Mesurer le pinceau"),
        arrayOf("الحجم", "Size", "Taille"),
        arrayOf("ترقيع الفراغات", "Patching gaps", "Réparation des vides"),
        arrayOf("اضغط أيقونة الفرش لفتح لوحة الفرشاة (التي فيها حقل Size)", "Tap the brush icon to open the brush panel (the one with the Size field)", "Touchez l'icône du pinceau pour ouvrir son panneau (avec le champ Size)"),
        arrayOf("افتح لوحة الفرشاة بنفسك حتى يظهر حقل Size ثم اضغط متابعة", "Open the brush panel yourself until the Size field shows, then tap Continue", "Ouvrez le panneau du pinceau jusqu'à voir le champ Size, puis touchez Continuer"),
        arrayOf("اضغط على حقل Size (الرقم الذي يُكتب فيه الحجم)", "Tap the Size field (the number you can type)", "Touchez le champ Size (le nombre à saisir)"),
        arrayOf("اضغط الزر الذي يُغلق اللوحة، وإن كانت تُغلق تلقائياً فاضغط تخطي", "Tap the button that closes the panel, or Skip if it closes by itself", "Touchez le bouton qui ferme le panneau, ou Ignorer s'il se ferme seul"),
        arrayOf("تم حفظ حقل Size. جاري معايرة الفرشاتين...", "Size field saved. Calibrating both brushes...", "Champ Size enregistré. Calibrage des deux pinceaux..."),
        arrayOf("تم مسح تعليم Size: سيُرسم بفرشاة واحدة", "Size teaching cleared: one brush will be used", "Taille effacée : un seul pinceau sera utilisé"),
        arrayOf("علّم حقل Size أولاً (زر الحجم)", "Teach the Size field first (Size button)", "Enseignez d'abord le champ Size (bouton Taille)"),
        arrayOf("لم أجد الخط التجريبي: تأكد أن وسط منطقة الرسم فارغ وأن لون الفرشاة يختلف عن لون الكانفس", "Test line not found: keep the middle of the drawing area empty and the brush colour different from the canvas", "Trait de test introuvable : gardez le centre vide et une couleur différente du canevas"),
        arrayOf("الحجم", "Size", "Taille"),
        arrayOf("متابعة", "Continue", "Continuer"),
        arrayOf("تخطي (غير مطلوب)", "Skip (not needed)", "Ignorer (inutile)"),
        // الواجهة الرئيسية
        arrayOf("منطقة غير مغلقة: تُلوَّن بالفرشاة بدل Fill", "unclosed areas: painted with the brush instead of Fill", "zones non fermées : coloriées au pinceau au lieu de Fill"),
        arrayOf("اختبار: سيُطبَّق الأحمر #FF0000", "Test: red #FF0000 will be applied", "Test : le rouge #FF0000 sera appliqué"),
        arrayOf("اكتمال الرسم", "Drawing finished", "Dessin terminé"),
        arrayOf("انتهى. ارسم خطاً بيدك: هل هو أحمر؟", "Done. Draw a line by hand: is it red?", "Terminé. Tracez un trait : est-il rouge ?"),
        arrayOf("تعذّر أخذ لقطة الشاشة (رمز", "Screenshot failed (code", "Capture d'écran impossible (code"),
        arrayOf("تعذّر القياس:", "Measurement failed:", "Mesure impossible :"),
        arrayOf("بنفسك", "yourself", "vous-même"),
        arrayOf("سمك الفرشاة المقاس =", "Measured brush size =", "Taille mesurée du pinceau ="),
        arrayOf("بكسل", "px", "px"),
        arrayOf("تراجع ↩ عن الخط التجريبي، ثم أعد فتح صفحة التطبيق", "Undo ↩ the test line, then reopen the app page", "Annulez ↩ le trait d'essai, puis rouvrez la page de l'app"),
        arrayOf("لم أجد الخط التجريبي: تأكد أن وسط منطقة الرسم فارغ وأن لون الفرشاة يختلف عن لون الكانفس", "Test line not found: make sure the middle of the drawing area is empty and the brush color differs from the canvas", "Trait d'essai introuvable : le centre de la zone doit être vide et la couleur du pinceau différente du canevas"),
        arrayOf("خطأ في التحليل:", "Analysis error:", "Erreur d'analyse :"),
        arrayOf("الطبقة", "Layer", "Calque"),
        arrayOf("الصورة", "Image", "Image"),
        arrayOf("الرسم", "Draw", "Dessin"),
        arrayOf("الإعدادات", "Settings", "Réglages"),
        arrayOf("اختيار صورة", "Choose image", "Choisir une image"),
        arrayOf("اختر صورة", "Choose image", "Choisir une image"),
        arrayOf("تفعيل الخدمة", "Enable service", "Activer le service"),
        arrayOf("لم تُختر صورة بعد", "No image selected yet", "Aucune image choisie"),
        arrayOf("جاري تحميل الصورة...", "Loading image...", "Chargement de l'image..."),
        arrayOf("تعذّر فتح الصورة", "Could not open the image", "Impossible d'ouvrir l'image"),
        arrayOf("معاينة سريعة...", "Quick preview...", "Aperçu rapide..."),
        arrayOf("المعاينة سريعة؛ جاري التحليل الكامل...", "Quick preview; full analysis running...", "Aperçu rapide ; analyse complète en cours..."),
        arrayOf("تمت إعادة الإعدادات الافتراضية", "Defaults restored", "Réglages par défaut rétablis"),
        arrayOf("مقاييس الرسم", "Drawing metrics", "Mesures de dessin"),
        arrayOf("خيارات الرسم", "Drawing options", "Options de dessin"),
        arrayOf("سواد الخطوط", "Line darkness", "Noirceur des traits"),
        arrayOf("تفاصيل الخطوط", "Line detail", "Détail des traits"),
        arrayOf("عدد الألوان", "Colors", "Couleurs"),
        arrayOf("سمك الفرشاة", "Brush size", "Taille du pinceau"),
        arrayOf("سرعة الرسم", "Draw speed", "Vitesse"),
        arrayOf("التلوين: فرشاة دقيقة", "Coloring: precise brush", "Coloriage : pinceau précis"),
        arrayOf("التلوين: تعبئة Fill", "Coloring: Fill tool", "Coloriage : Remplissage"),
        arrayOf("البياض المحصور: خلفية", "Enclosed white: background", "Blanc enclos : fond"),
        arrayOf("البياض المحصور: يُرسم أبيض", "Enclosed white: drawn white", "Blanc enclos : dessiné"),
        arrayOf("الطبقات: طبقة لكل لون", "Layers: one per color", "Calques : un par couleur"),
        arrayOf("الطبقات: طبقة واحدة", "Layers: single layer", "Calques : un seul")
    ).sortedByDescending { it[0].length }

    private val rx: List<Regex> = D.map { Regex("(?<![\\u0600-\\u06FF])" + Regex.escape(it[0]) + "(?![\\u0600-\\u06FF])") }

    fun t(s: String): String {
        if (lang == "ar") return s
        val i = if (lang == "en") 1 else 2
        for (e in D) if (e[0] == s) return e[i]
        var r = s
        for (k in D.indices) if (r.contains(D[k][0])) r = rx[k].replace(r, Regex.escapeReplacement(D[k][i]))
        return r
    }
}
