package com.sketchbot.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    companion object {
        var keepBmp: Bitmap? = null
        var keepLoaded: Tracer.Loaded? = null
    }
    private var cur = -1
    private lateinit var navRow: LinearLayout
    private lateinit var indicator: View
    private var indW = -1

    private var bitmap: Bitmap? = null
    private var loaded: Tracer.Loaded? = null
    private var threshold = 55
    private var detail = 40
    private var brushPx = 3
    // تحليل واحد فقط في كل مرة: يمنع تراكم المعالجات الثقيلة عند تحريك الأشرطة (سبب البطء والسقوط)
    private val procLock = Any()
    private var introMp: android.media.MediaPlayer? = null
    private lateinit var brushPanel: BrushPanel
    private var simBmp: Bitmap? = null
    private var idealBmp: Bitmap? = null
    private var libSig = ""

    private fun libSignature(): String {
        val p = getSharedPreferences("sb", MODE_PRIVATE)
        return (p.getString("brushLib", "") ?: "") + "|" + BrushLib.taught(this).sorted().joinToString(",")
    }

    private fun redisplayPreview(showSim: Boolean) {
        val s = simBmp
        val i = idealBmp
        if (showSim && s != null) showPreview(s) else if (i != null) showPreview(i)
    }

    // تقرير الأحجام المستخدمة لكل فرشاة وعدد الخطوط بكل حجم
    private fun smartReport(phases: List<Phase>): String {
        val names = HashMap<Long, String>()
        for (b in BrushLib.load(this)) names[b.id] = b.name
        val perBrush = LinkedHashMap<Long, java.util.TreeMap<Int, Int>>()
        var total = 0
        for (ph in phases) for (t in ph.tiers) {
            val mp = perBrush.getOrPut(t.brush) { java.util.TreeMap() }
            mp[t.size] = (mp[t.size] ?: 0) + t.strokes.size
            total += t.strokes.size
        }
        val sb = StringBuilder()
        var sizes = 0
        for ((id, mp) in perBrush) {
            sizes += mp.size
            sb.append("• ").append(names[id] ?: Tr.t("فرشاة")).append(": ")
            sb.append(mp.entries.joinToString("، ") { "${it.key} (${it.value})" }).append("\n")
        }
        return Tr.t("خطة الأحجام Size (بين القوسين عدد الخطوط)") + "\n" + sb.toString().trimEnd() + "\n" +
            Tr.t("الإجمالي") + ": $sizes " + Tr.t("حجماً") + " | $total " + Tr.t("خطاً")
    }

    private fun releaseIntroSound() {
        try { introMp?.release() } catch (_: Throwable) {}
        introMp = null
    }

    override fun onDestroy() {
        releaseIntroSound()
        super.onDestroy()
    }
    private var colors = 36
    private var fillMode = false
    private var soft = 0
    private var blend = false
    private var pockets = true
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var thLabel: TextView
    private lateinit var dtLabel: TextView
    private lateinit var fgLabel: TextView
    private lateinit var clLabel: TextView

    private lateinit var previewOrig: ImageView
    private lateinit var previewSmall: ImageView
    private lateinit var pages: Array<View>
    private lateinit var navItems: Array<NavItem>

    private fun moveIndicator(i: Int, animate: Boolean) {
        val ni = navItems[i]
        if (ni.width == 0) return
        val lp = indicator.layoutParams as FrameLayout.LayoutParams
        val inset = (6 * resources.displayMetrics.density).toInt()
        if (lp.width != ni.width - 2 * inset || lp.height != ni.height) {
            lp.width = ni.width - 2 * inset
            lp.height = ni.height
            indicator.layoutParams = lp
        }
        indW = ni.width
        val tx = (navRow.left + ni.left + inset).toFloat()
        val ty = (navRow.top + ni.top).toFloat()
        indicator.animate().cancel()
        indAnim?.cancel()
        if (!animate) {
            indicator.translationX = tx
            indicator.translationY = ty
            syncNav()
        } else {
            val sx = indicator.translationX
            val sy = indicator.translationY
            indAnim = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 380
                interpolator = DecelerateInterpolator(1.8f)
                addUpdateListener {
                    val f = it.animatedValue as Float
                    indicator.translationX = sx + (tx - sx) * f
                    indicator.translationY = sy + (ty - sy) * f
                    syncNav()
                }
                start()
            }
        }
    }

    private var indAnim: android.animation.ValueAnimator? = null

    // الأيقونة تتلوّن بالأبيض وتكبر بقدر تداخل المؤشر البرتقالي معها فقط: لا تخرج أبداً خارج الإطار
    private fun syncNav() {
        val cx = indicator.translationX + (indicator.layoutParams.width) / 2f
        for (ni in navItems) {
            if (ni.width == 0) continue
            val icx = (navRow.left + ni.left) + ni.width / 2f
            ni.setProgress(1f - Math.abs(cx - icx) / (ni.width * 0.8f))
        }
    }

    private fun selectTab(i: Int) {
        if (i == cur) return
        val prev = cur
        cur = i
        val dn = resources.displayMetrics.density
        for (k in navItems.indices) navItems[k].setActive(k == i, prev >= 0)
        moveIndicator(i, prev >= 0)
        val dir = if (prev < 0 || i > prev) 1f else -1f
        for (k in pages.indices) {
            val p = pages[k]
            if (k == i) {
                p.animate().cancel()
                p.visibility = View.VISIBLE
                p.alpha = 0f
                p.translationX = dir * 36f * dn
                p.animate().alpha(1f).translationX(0f).setDuration(300)
                    .setInterpolator(DecelerateInterpolator(1.6f)).withLayer().start()
                val col = (p as ViewGroup).getChildAt(0) as ViewGroup
                for (j in 0 until col.childCount) {
                    val ch = col.getChildAt(j)
                    ch.animate().cancel()
                    ch.alpha = 0f
                    ch.translationY = 28f * dn
                    ch.animate().alpha(1f).translationY(0f).setStartDelay(60L + j * 55L).setDuration(380)
                        .setInterpolator(DecelerateInterpolator(2f)).start()
                }
            } else if (k == prev) {
                p.animate().cancel()
                p.animate().alpha(0f).translationX(-dir * 28f * dn).setDuration(180).withLayer()
                    .withEndAction { if (cur != k) p.visibility = View.GONE }.start()
            } else {
                p.animate().cancel()
                p.visibility = View.GONE
            }
        }
    }

    override fun onSaveInstanceState(o: Bundle) {
        super.onSaveInstanceState(o)
        o.putInt("th", threshold); o.putInt("dt", detail); o.putInt("bp", brushPx); o.putInt("cl", colors)
        o.putBoolean("fm", fillMode); o.putInt("sf", soft); o.putBoolean("bl", blend); o.putBoolean("pk", pockets)
        o.putInt("tab", cur)
    }

    private fun showPreview(b: Bitmap) {
        preview.setImageBitmap(b)
        previewSmall.setImageBitmap(b)
    }

    private fun styleSeek(s: SeekBar) {
        val d = resources.displayMetrics.density
        val h = (8 * d).toInt()
        val bg = GradientDrawable().apply { cornerRadius = h / 2f; setColor(Th.TRACK); setSize(0, h) }
        val pr = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor("#F26B1D"), Color.parseColor("#FFA23A")))
            .apply { cornerRadius = h / 2f; setSize(0, h) }
        val clip = ClipDrawable(pr, Gravity.START, ClipDrawable.HORIZONTAL)
        val ld = LayerDrawable(arrayOf<Drawable>(bg, clip))
        ld.setId(0, android.R.id.background)
        ld.setId(1, android.R.id.progress)
        s.progressDrawable = ld
        s.thumb = orangeThumb(this)
        s.splitTrack = false
        s.setPadding((13 * d).toInt(), 0, (13 * d).toInt(), 0)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Th.init(this)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Th.CREAM))
        if (b != null) {
            threshold = b.getInt("th", threshold); detail = b.getInt("dt", detail); brushPx = b.getInt("bp", brushPx)
            colors = b.getInt("cl", colors); fillMode = b.getBoolean("fm", fillMode); soft = b.getInt("sf", soft)
            blend = b.getBoolean("bl", blend); pockets = b.getBoolean("pk", pockets)
        }
        try {
            // أعلى معدل تحديث للشاشة (60/90/120Hz) لحركة سلسة
            @Suppress("DEPRECATION")
            val dm = windowManager.defaultDisplay
            val cm = dm.mode
            var best = cm
            for (m in dm.supportedModes) if (m.physicalWidth == cm.physicalWidth && m.physicalHeight == cm.physicalHeight && m.refreshRate > best.refreshRate) best = m
            val wa = window.attributes
            wa.preferredDisplayModeId = best.modeId
            window.attributes = wa
        } catch (_: Throwable) {}
        val d = resources.displayMetrics.density
        fun dp(v: Float) = (v * d).toInt()
        window.statusBarColor = Th.CREAM
        window.navigationBarColor = Th.NAV2
        window.decorView.systemUiVisibility = if (Th.dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val screenH = resources.displayMetrics.heightPixels

        fun lpv(top: Int, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = dp(top.toFloat()) }

        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = WarmDrawable(WarmDrawable.GLASS, 26f, d)
            setPadding(dp(14f), dp(14f), dp(14f), dp(14f))
            elevation = 6f * d
        }

        fun previewCard(img: ImageView, height: Int): FrameLayout {
            img.apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Th.PBG)
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, 18 * d) }
                }
                clipToOutline = true
            }
            return FrameLayout(this).apply {
                background = WarmDrawable(WarmDrawable.CARD, 24f, d)
                setPadding(dp(6f), dp(6f), dp(6f), dp(6f))
                elevation = 2f * d
                addView(img, FrameLayout.LayoutParams(-1, height - dp(12f)))
            }
        }

        fun header(leftIcon: Int, title: String, rightIcon: Int, onLeft: () -> Unit, onRight: () -> Unit, underline: Boolean): FrameLayout {
            val fl = FrameLayout(this)
            val left = Th.squareBtn(this, leftIcon, Th.BROWN)
            val right = Th.squareBtn(this, rightIcon, Th.BROWN)
            left.setOnClickListener { onLeft() }
            right.setOnClickListener { onRight() }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                addView(Th.text(this@MainActivity, title, 26f, Th.BROWN, true), LinearLayout.LayoutParams(-2, -2))
                if (underline) addView(View(this@MainActivity).apply {
                    background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor("#F26B1D"), Color.parseColor("#FFA23A"))).apply { cornerRadius = 4f * d }
                }, LinearLayout.LayoutParams(dp(70f), dp(5f)).apply { topMargin = dp(4f) })
            }
            fl.addView(left, FrameLayout.LayoutParams(dp(46f), dp(46f), Gravity.START or Gravity.CENTER_VERTICAL))
            fl.addView(right, FrameLayout.LayoutParams(dp(46f), dp(46f), Gravity.END or Gravity.CENTER_VERTICAL))
            fl.addView(col, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            return fl
        }

        fun bigButton(icon: Int, label: String, orange: Boolean): LinearLayout = DropLinear(this).apply {
            dropColor = if (orange) Color.parseColor("#FF8A1F") else Color.parseColor("#E5470B")
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = WarmDrawable(if (orange) WarmDrawable.ORANGE else WarmDrawable.BTN, 26f, d)
            elevation = 3f * d
            addView(IconView(this@MainActivity, icon, 0, 0, if (orange) Color.WHITE else Color.parseColor("#B5461B")), LinearLayout.LayoutParams(dp(28f), dp(28f)))
            addView(Th.text(this@MainActivity, label, 18f, if (orange) Color.WHITE else Th.BROWN, true).apply { setPadding(dp(12f), 0, 0, 0) })
        }

        // ---------- عناصر مشتركة ----------
        preview = ImageView(this)
        previewSmall = ImageView(this)
        previewOrig = ImageView(this)
        status = Th.text(this, "لم تُختر صورة بعد", 12.5f, Th.MUTED).apply { gravity = Gravity.CENTER }

        thLabel = Th.text(this, "$threshold", 15f, Th.BROWN, true).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        dtLabel = Th.text(this, "$detail", 15f, Th.BROWN, true).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        clLabel = Th.text(this, "$colors", 15f, Th.BROWN, true).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        fgLabel = Th.text(this, "$brushPx", 15f, Th.BROWN, true).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        val spLabel = Th.text(this, "x${Shared.speed.toInt()}", 15f, Th.BROWN, true).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        val seekTh = SeekBar(this).apply { max = 120; progress = threshold - 20 }
        val seekDt = SeekBar(this).apply { max = 100; progress = detail }
        val seekCl = SeekBar(this).apply { max = 128; progress = colors }
        val seekFg = SeekBar(this).apply { max = 19; progress = brushPx - 1 }
        val seekSp = SeekBar(this).apply { max = 9; progress = Shared.speed.toInt() - 1 }
        for (s in listOf(seekTh, seekDt, seekCl, seekFg, seekSp)) styleSeek(s)

        fun sliderRow(icon: Int, c1: String, c2: String, label: String, seek: SeekBar, value: TextView, last: Boolean): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(IconView(this@MainActivity, icon, Color.parseColor(c1), Color.parseColor(c2), 0, true), LinearLayout.LayoutParams(dp(30f), dp(30f)))
                addView(Th.text(this@MainActivity, label, 12.5f, Th.BROWN, true).apply { maxLines = 2 }, LinearLayout.LayoutParams(dp(84f), -2).apply { leftMargin = dp(8f) })
                addView(seek, LinearLayout.LayoutParams(0, dp(40f), 1f))
                addView(value, LinearLayout.LayoutParams(dp(44f), -2))
            }, LinearLayout.LayoutParams(-1, dp(46f)))
            if (!last) addView(View(this@MainActivity).apply { setBackgroundColor(Th.LINE) }, LinearLayout.LayoutParams(-1, dp(1f)))
        }

        val labMode = Th.text(this, "التلوين: فرشاة دقيقة", 14.5f, Th.BROWN, true)
        val labPock = Th.text(this, "البياض المحصور: خلفية", 14.5f, Th.BROWN, true)
        val labLay = Th.text(this, "الطبقات: طبقة لكل لون", 14.5f, Th.BROWN, true)
        val swMode = WarmSwitch(this).apply { checked = !fillMode }
        val swPock = WarmSwitch(this).apply { checked = pockets }
        val swLay = WarmSwitch(this).apply { checked = Shared.layers }

        fun optionRow(icon: Int, c1: String, c2: String, lab: TextView, sw: WarmSwitch): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = WarmDrawable(WarmDrawable.GLASS, 20f, d)
            elevation = 3f * d
            setPadding(dp(12f), dp(10f), dp(14f), dp(10f))
            addView(IconView(this@MainActivity, icon, Color.parseColor(c1), Color.parseColor(c2), 0, true), LinearLayout.LayoutParams(dp(38f), dp(38f)))
            addView(lab, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14f) })
            addView(sw)
        }

        fun cardTitle(icon: Int, title: String, c1: String, c2: String): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(IconView(this@MainActivity, icon, Color.parseColor(c1), Color.parseColor(c2), 0, true), LinearLayout.LayoutParams(dp(52f), dp(52f)))
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(Th.text(this@MainActivity, title, 18f, Th.BROWN, true))
                addView(View(this@MainActivity).apply { setBackgroundColor(Th.LINE) }, LinearLayout.LayoutParams(-1, dp(1f)).apply { topMargin = dp(8f) })
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14f) })
        }

        // ---------- الصفحة 1: الصورة ----------
        val btnPick = bigButton(Ic.IMAGE, "اختيار صورة", true)
        val btnAcc = bigButton(Ic.POWER, "تفعيل الخدمة", false)
        val gearTop = Th.squareBtn(this, Ic.GEAR, Th.BROWN, 46f)
        val langBtn = FrameLayout(this).apply {
            background = WarmDrawable(WarmDrawable.GLASS, 12f, d)
            elevation = 3f * d
            addView(Th.text(this@MainActivity, Tr.lang.uppercase(), 12f, Color.parseColor("#E5470B"), true), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            Th.pressable(this)
        }
        val themeBtn = Th.squareBtn(this, if (Th.dark) Ic.SUN else Ic.MOON, if (Th.dark) Color.parseColor("#FFC45E") else Color.parseColor("#B5461B"), 34f)
        val head1 = FrameLayout(this).apply {
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                addView(Th.text(this@MainActivity, "MR NEGROO", 25f, Th.BROWN, true), LinearLayout.LayoutParams(-2, -2))
                addView(Th.text(this@MainActivity, "SKETCH STUDIO", 12f, Color.parseColor("#B5461B")).apply { letterSpacing = 0.3f }, LinearLayout.LayoutParams(-2, -2))
            }, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            addView(gearTop, FrameLayout.LayoutParams(dp(46f), dp(46f), Gravity.END or Gravity.CENTER_VERTICAL))
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(langBtn, LinearLayout.LayoutParams(dp(34f), dp(34f)))
                addView(themeBtn, LinearLayout.LayoutParams(dp(34f), dp(34f)).apply { leftMargin = dp(6f) })
            }, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL))
        }
        val page1 = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(40f), dp(18f), dp(120f))
            addView(head1, lpv(0))
            addView(previewCard(previewOrig, (screenH * 0.5f).toInt()), lpv(14))
            addView(btnPick, lpv(16, dp(64f)))
            addView(btnAcc, lpv(12, dp(56f)))
        }

        // ---------- الصفحة 2: الرسم ----------
        val brushBtn = Th.squareBtn(this, Ic.BRUSH, Th.BROWN, 64f, outlined = true)
        val dotBtn = FrameLayout(this).apply {
            background = WarmDrawable(WarmDrawable.BTN, 16f, d)
            addView(View(this@MainActivity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#FF8A1F"), Color.parseColor("#E5300A"))).apply { shape = GradientDrawable.OVAL }
            }, FrameLayout.LayoutParams(dp(34f), dp(34f), Gravity.CENTER))
            Th.pressable(this)
        }
        val dotText = Th.text(this, "$colors", 11f, Color.WHITE, true)
        dotBtn.addView(dotText, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        val undoBtn = Th.squareBtn(this, Ic.UNDO, Th.BROWN, 64f)
        brushPanel = BrushPanel(this, { process() }, { v -> redisplayPreview(v) })
        val gearBtn = Th.squareBtn(this, Ic.GEAR, Th.BROWN, 64f, orange = true)
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            for (v in listOf<View>(brushBtn, dotBtn, undoBtn, gearBtn))
                addView(v, LinearLayout.LayoutParams(0, dp(64f), 1f).apply { setMargins(dp(5f), 0, dp(5f), 0) })
        }
        val page2 = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(40f), dp(18f), dp(120f))
            addView(header(Ic.BACK, "الرسم", Ic.POWER, { selectTab(0) }, { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, false), lpv(0))
            addView(previewCard(preview, (screenH * 0.5f).toInt()), lpv(14))
            addView(status, lpv(8))
            addView(tools, lpv(14))
            addView(brushPanel, lpv(14))
        }

        // ---------- الصفحة 3: الإعدادات ----------
        val measCard = card().apply {
            addView(cardTitle(Ic.SLIDERS, "مقاييس الرسم", "#FFA23A", "#E8500B"))
            addView(sliderRow(Ic.PENCIL, "#8A6A5A", "#4A2E22", "سواد الخطوط", seekTh, thLabel, false), lpv(10))
            addView(sliderRow(Ic.AREA, "#FFAA3C", "#EA620F", "تفاصيل الخطوط", seekDt, dtLabel, false))
            addView(sliderRow(Ic.PALETTE, "#FF8654", "#E03A1E", "عدد الألوان", seekCl, clLabel, false))
            addView(sliderRow(Ic.BRUSH, "#BE848C", "#7A4A52", "سمك الفرشاة", seekFg, fgLabel, false))
            addView(sliderRow(Ic.PLAY, "#FFA23A", "#E8500B", "سرعة الرسم", seekSp, spLabel, true))
        }
        val optCard = card().apply {
            addView(cardTitle(Ic.BRUSH, "خيارات الرسم", "#A47552", "#6B4228"))
            addView(optionRow(Ic.PENCIL, "#FFAA3C", "#EA620F", labMode, swMode), lpv(12))
            addView(optionRow(Ic.CHECKER, "#BE848C", "#7A4A52", labPock, swPock), lpv(8))
            addView(optionRow(Ic.LAYERS, "#A47552", "#6B4228", labLay, swLay), lpv(8))
        }
        val gearTitle = Th.squareBtn(this, Ic.GEAR, Th.BROWN, 46f)
        val page3 = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(40f), dp(18f), dp(120f))
            addView(header(Ic.BACK, "الإعدادات", Ic.GEAR, { selectTab(1) }, {}, true), lpv(0))
            addView(previewCard(previewSmall, dp(230f)), lpv(12))
            addView(measCard, lpv(14))
            addView(optCard, lpv(14))
        }

        pages = arrayOf<View>(
            ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(page1) },
            ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(page2) },
            ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(page3) }
        )
        navItems = arrayOf(NavItem(this, Ic.IMAGE, "الصورة"), NavItem(this, Ic.PENCIL, "الرسم"), NavItem(this, Ic.GEAR, "الإعدادات"))
        navRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(8f), dp(16f), dp(14f))
            for (ni in navItems) addView(ni, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4f), 0, dp(4f), 0) })
        }
        indicator = View(this).apply { background = WarmDrawable(WarmDrawable.ACTIVE, 22f, d) }
        val nav = FrameLayout(this).apply {
            background = WarmDrawable(WarmDrawable.NAV, 34f, d, true)
            addView(indicator, FrameLayout.LayoutParams(0, 0, Gravity.TOP or Gravity.START))
            addView(navRow, FrameLayout.LayoutParams(-1, -1))
            addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
                if (cur >= 0 && navItems[cur].width != 0 && navItems[cur].width != indW) moveIndicator(cur, false)
            }
        }
        for (i in navItems.indices) navItems[i].setOnClickListener { selectTab(i) }

        val frame = FrameLayout(this)
        frame.setBackgroundColor(Th.CREAM)
        for (p in pages) frame.addView(p, FrameLayout.LayoutParams(-1, -1))
        frame.addView(nav, FrameLayout.LayoutParams(-1, dp(96f), Gravity.BOTTOM))
        setContentView(frame)
        selectTab(b?.getInt("tab", 0) ?: 0)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 9)
        }

        // ---------- الإنترو: لوجو زجاجي سائل (WebGL داخل WebView) ----------
        if (b == null) {
            try {
                val wv = android.webkit.WebView(this)
                wv.setBackgroundColor(Color.BLACK)
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                var gone = false
                // المؤثر الصوتي يُحضَّر مسبقاً ليبدأ فوراً مع أول حركة (أي خطأ فيه لا يمنع الإنترو)
                introMp = try { android.media.MediaPlayer.create(this, R.raw.intro_sfx)?.apply { setVolume(1f, 1f) } } catch (_: Throwable) { null }
                fun closeIntro() {
                    if (gone) return
                    gone = true
                    wv.animate().alpha(0f).setDuration(450).withEndAction {
                        frame.removeView(wv)
                        try { wv.destroy() } catch (_: Throwable) {}
                        releaseIntroSound()
                    }.start()
                }
                wv.addJavascriptInterface(object {
                    @android.webkit.JavascriptInterface
                    fun done() { runOnUiThread { closeIntro() } }
                    @android.webkit.JavascriptInterface
                    fun sfx() { runOnUiThread { try { if (!gone) introMp?.start() } catch (_: Throwable) {} } }
                }, "Android")
                wv.setOnTouchListener { _, e ->
                    if (e.action == android.view.MotionEvent.ACTION_UP) closeIntro()
                    true
                }
                frame.addView(wv, FrameLayout.LayoutParams(-1, -1))
                wv.loadUrl("file:///android_asset/intro.html")
                frame.postDelayed({ closeIntro() }, 8000)
            } catch (_: Throwable) {}
        }

        // ---------- الأحداث ----------
        langBtn.setOnClickListener { Tr.next(this); recreate() }
        themeBtn.setOnClickListener {
            val loc = IntArray(2)
            themeBtn.getLocationOnScreen(loc)
            val toDark = !Th.dark
            val target = if (toDark) Color.parseColor("#0B0604") else Color.parseColor("#FCF3EA")
            val rim = if (toDark) Color.parseColor("#3A2316") else Color.parseColor("#F5B77A")
            themeBtn.isEnabled = false
            val v = VenomView(this, loc[0] + themeBtn.width / 2f, loc[1] + themeBtn.height / 2f, target, rim) {
                getSharedPreferences("sb", MODE_PRIVATE).edit()
                    .putBoolean("dark", toDark).putInt("reveal", target).apply()
                recreate()
                overridePendingTransition(0, 0)
            }
            (window.decorView as ViewGroup).addView(v, ViewGroup.LayoutParams(-1, -1))
        }
        val rv = getSharedPreferences("sb", MODE_PRIVATE)
        if (rv.contains("reveal")) {
            val col = rv.getInt("reveal", 0)
            rv.edit().remove("reveal").apply()
            val cover = View(this).apply { setBackgroundColor(col); isClickable = true }
            frame.addView(cover, FrameLayout.LayoutParams(-1, -1))
            cover.animate().alpha(0f).setStartDelay(160).setDuration(520).withEndAction { frame.removeView(cover) }.start()
        }
        if (b != null && keepBmp != null) {
            bitmap = keepBmp
            loaded = keepLoaded
            previewOrig.setImageBitmap(bitmap)
            frame.post { process() }
        }
        gearTop.setOnClickListener { selectTab(2) }
        gearBtn.setOnClickListener { selectTab(2) }
        btnAcc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btnPick.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(i, Tr.t("اختر صورة")), 1)
        }

        fun applyMode(precise: Boolean) {
            fillMode = !precise
            labMode.text = Tr.t(if (precise) "التلوين: فرشاة دقيقة" else "التلوين: تعبئة Fill")
            swMode.checked = precise
            process()
        }
        swMode.onChange = { v -> applyMode(v) }
        brushBtn.setOnClickListener { applyMode(fillMode) }
        swPock.onChange = { v ->
            pockets = v
            labPock.text = Tr.t(if (v) "البياض المحصور: خلفية" else "البياض المحصور: يُرسم أبيض")
            process()
        }
        swLay.onChange = { v ->
            Shared.layers = v
            labLay.text = Tr.t(if (v) "الطبقات: طبقة لكل لون" else "الطبقات: طبقة واحدة")
        }
        val presets = intArrayOf(8, 14, 24, 36, 48, 64, 96, 128)
        dotBtn.setOnClickListener {
            var nx = presets[0]
            for (pv in presets) if (pv > colors) { nx = pv; break }
            colors = nx
            seekCl.progress = nx
            clLabel.text = "$nx"
            dotText.text = "$nx"
            process()
        }
        undoBtn.setOnClickListener {
            threshold = 55; detail = 40; colors = 36; brushPx = 3
            Shared.speed = 4f
            seekTh.progress = threshold - 20
            seekDt.progress = detail
            seekCl.progress = colors
            seekFg.progress = brushPx - 1
            seekSp.progress = 3
            thLabel.text = "$threshold"; dtLabel.text = "$detail"; clLabel.text = "$colors"; fgLabel.text = "$brushPx"; spLabel.text = "x4"
            dotText.text = "$colors"
            Toast.makeText(this, Tr.t("تمت إعادة الإعدادات الافتراضية"), Toast.LENGTH_SHORT).show()
            process()
        }

        fun bind(seek: SeekBar, onChange: (Int) -> Unit) {
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { process() }
            })
        }
        bind(seekTh) { p -> threshold = 20 + p; thLabel.text = "$threshold" }
        bind(seekDt) { p -> detail = p; dtLabel.text = "$detail" }
        bind(seekCl) { p -> colors = p; clLabel.text = "$colors"; dotText.text = "$colors" }
        seekSp.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                Shared.speed = (1 + p).toFloat()
                spLabel.text = "x${1 + p}"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { process() }
        })
        bind(seekFg) { p -> getSharedPreferences("sb", MODE_PRIVATE).edit().remove("brushScreen").apply(); brushPx = 1 + p; fgLabel.text = "$brushPx" }
    }

    override fun onResume() {
        super.onResume()
        try { brushPanel.refresh() } catch (_: Throwable) {}
        val sig = libSignature()
        if (bitmap != null && (Shared.phases.isEmpty() || (sig != libSig && brushPanel.smartOn))) process()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            status.text = Tr.t("جاري تحميل الصورة...")
            thread {
                val ld = Tracer.load(this, uri, 1500)
                runOnUiThread {
                    if (ld == null) {
                        status.text = Tr.t("تعذّر فتح الصورة")
                    } else {
                        bitmap = ld.bmp
                        loaded = ld
                        keepBmp = ld.bmp
                        keepLoaded = ld
                        previewOrig.setImageBitmap(ld.bmp)
                        selectTab(1)
                        process()
                    }
                }
            }
        }
    }

    // كم بكسل على الشاشة يساوي بكسل واحد من الصورة المحلَّلة (حسب منطقة الرسم المحفوظة)
    private fun screenScale(bmp: Bitmap): Float {
        val p = getSharedPreferences("sb", MODE_PRIVATE)
        var rw = resources.displayMetrics.widthPixels * 0.9f
        var rh = resources.displayMetrics.heightPixels * 0.7f
        if (p.contains("l")) {
            rw = p.getFloat("r", 0f) - p.getFloat("l", 0f)
            rh = p.getFloat("b", 0f) - p.getFloat("t", 0f)
        }
        val s = Math.min(rw / bmp.width, rh / bmp.height)
        return Math.max(0.05f, s)
    }

    private var gen = 0
    private val uiHandler = Handler(Looper.getMainLooper())
    private var fullJob: Runnable? = null

    // معاينة سريعة (دقة منخفضة) فوراً، ثم التحليل الكامل بعد توقف التعديل ~0.9 ث (وأي تحليل قديم يُلغى)
    private fun process() {
        val bmp = bitmap ?: return
        val ld = loaded ?: return
        val my = ++gen
        fullJob?.let { uiHandler.removeCallbacks(it) }
        status.text = Tr.t("معاينة سريعة...")
        val t = threshold
        val dt = detail
        val sc = screenScale(bmp)
        val measured = getSharedPreferences("sb", MODE_PRIVATE).getFloat("brushScreen", 0f)
        val eff = if (measured > 0f) measured else brushPx.toFloat()
        val fg = Math.max(1, Math.round(eff * 0.6f / sc))
        // فرشاة صغيرة جداً: نكبّر الصورة قبل التحليل حتى يصير عرض الفرشاة ≥3 بكسل فتُغطّى كل المناطق بدقة
        val bw = eff / sc
        var up = 1f
        if (bw < 3f) up = Math.min(Math.ceil((3f / bw).toDouble()).toFloat(), 2200f / Math.max(bmp.width, bmp.height))
        if (up < 1.05f) up = 1f
        val scFull = sc / up
        val fgFull = Math.max(1, Math.round(eff * 0.6f / scFull))
        val sp = getSharedPreferences("sb", MODE_PRIVATE)
        val bigScr = sp.getFloat("bigScreen", 0f)
        val dualOn = bigScr > eff * 1.5f && sp.getString("sizeSel", null) != null
        val bigFgFull = if (dualOn) Math.max(fgFull + 1, Math.round(bigScr * 0.6f / scFull)) else 0
        Shared.smallPx = eff
        Shared.bigPx = if (dualOn) bigScr else 0f
        val cl = colors
        val fm = fillMode
        val sf = soft
        val bl = blend
        val pk = pockets
        val sn = Shared.speed <= 2f
        // الوضع الذكي: فرشات المكتبة (الفرشاة الأساسية = أول فرشاة مفعّلة)
        val lib = BrushLib.load(this)
        val primaryB = lib.firstOrNull { it.on }
        val taught = BrushLib.taught(this)
        val smartOn = brushPanel.smartOn && !fm && primaryB != null
        val chFull: Chooser? = if (smartOn && primaryB != null) LibChooser(lib, primaryB.id, scFull, taught) else null
        val chSmall: Chooser? = if (smartOn && primaryB != null) LibChooser(lib, primaryB.id, sc, taught) else null
        val tierN = brushPanel.tierCount
        Shared.smart = chFull != null
        libSig = libSignature()
        if (primaryB != null) sp.edit().putLong("primaryBrush", primaryB.id).apply()
        // 1) معاينة سريعة على نسخة مصغّرة
        val k = 0.3f
        thread {
            try {
                synchronized(procLock) {
                    if (my != gen) return@thread
                    val sw = Math.max(64, (bmp.width * k).toInt())
                    val sh = Math.max(64, (bmp.height * k).toInt())
                    val small = Bitmap.createScaledBitmap(bmp, sw, sh, true)
                    Tracer.cancelCheck = { my != gen }
                    try {
                        val r = Tracer.process(small, t, dt, Math.max(1, Math.round(fg * k)), Math.min(cl, 24), false, sf, bl, sn, pk, 0, true)
                        runOnUiThread { if (my == gen) { showPreview(r.preview); status.text = Tr.t("المعاينة سريعة؛ جاري التحليل الكامل...") } }
                    } finally { Tracer.cancelCheck = null }
                }
            } catch (_: Throwable) {}
        }
        // 2) التحليل الكامل بعد توقف المستخدم عن التعديل
        val job = Runnable {
            thread {
                try {
                    if (my != gen) return@thread
                    val r = synchronized(procLock) {
                        if (my != gen) return@thread
                        // الصورة تظهر فور اكتمال التحليل اللوني، ثم يكمل تجهيز خطوط الرسم في الخلفية
                        val early: (Bitmap) -> Unit = { bm ->
                            runOnUiThread {
                                if (my == gen) { showPreview(bm); status.text = Tr.t("المعاينة جاهزة؛ جاري تجهيز خطوط الرسم...") }
                            }
                        }
                        Tracer.cancelCheck = { my != gen }
                        try {
                            try {
                                val srcFull = if (up > 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * up).toInt(), (bmp.height * up).toInt(), true) else bmp
                                Tracer.process(srcFull, t, dt, fgFull, cl, fm, sf, bl, sn, pk, bigFgFull, false, early, chFull, tierN)
                            } catch (_: OutOfMemoryError) {
                                // نقص ذاكرة: نحرّر ما نستطيع ونعيد المحاولة بالصورة بحجمها العادي بدل سقوط التطبيق
                                System.gc()
                                Tracer.process(bmp, t, dt, Math.max(1, Math.round(eff * 0.6f / sc)), cl, fm, sf, bl, sn, pk, 0, false, early, chSmall, tierN)
                            }
                        } finally { Tracer.cancelCheck = null }
                    }
                    // محاكاة الصورة بعرض كل فرشاة حقيقي (في الخلفية حتى لا تتجمد الواجهة)
                    val sim: Bitmap? = if (chFull != null && r.phases.any { it.tiers.isNotEmpty() }) {
                        try { Sim.render(r.phases, r.w, r.h) } catch (_: Throwable) { null }
                    } else null
                    val rep = if (sim != null) smartReport(r.phases) else ""
                    runOnUiThread {
                        if (my != gen) return@runOnUiThread
                        Shared.phases = r.phases
                        Shared.lbl = r.lbl
                        Shared.imgW = r.w
                        Shared.imgH = r.h
                        Shared.fx0 = ld.fx0
                        Shared.fy0 = ld.fy0
                        Shared.fw = ld.fw
                        Shared.fh = ld.fh
                        Shared.aspect = ld.aspect
                        idealBmp = r.preview
                        simBmp = sim
                        showPreview(if (brushPanel.showSim && sim != null) sim else r.preview)
                        brushPanel.setReport(rep)
                        var total = 0
                        for (p in r.phases) total += p.strokes.size
                        val want = r.lineThick * scFull
                        val mb = getSharedPreferences("sb", MODE_PRIVATE).getFloat("brushScreen", 0f)
                        val rec = if (want > 0f && sim == null) {
                            " | سمك الخطوط الأصلي ≈ ${"%.1f".format(want)} بكسل" +
                                (if (mb > 0f) " | فرشاتك المقاسة = ${mb.toInt()} بكسل" +
                                    (if (mb > want * 1.4f) ": كبيرة، صغّر Size إلى ${"%.0f".format(100f * want / mb)}% تقريباً" else ": مناسبة")
                                else " | قِس فرشاتك بزر 📏")
                        } else ""
                        status.text = when (Tr.lang) {
                            "en" -> "Ready: ${r.phases.size} phases, $total strokes" + (if (want > 0f) " | original line ≈ ${"%.1f".format(want)} px" else "")
                            "fr" -> "Prêt : ${r.phases.size} étapes, $total traits" + (if (want > 0f) " | trait d'origine ≈ ${"%.1f".format(want)} px" else "")
                            else -> "جاهز: ${r.phases.size} مرحلة، $total خط$rec" + (if (sim != null) " | ★ ذكي" else "")
                        }
                    }
                } catch (_: java.util.concurrent.CancellationException) {
                    // تحليل قديم أُلغي لأن المستخدم غيّر إعداداً: لا شيء يُعرض
                } catch (e: Throwable) {
                    runOnUiThread { if (my == gen) status.text = "خطأ في التحليل: ${e.message}" }
                }
            }
        }
        fullJob = job
        uiHandler.postDelayed(job, 350)
    }
}
